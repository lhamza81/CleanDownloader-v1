package com.example.cleanbrowser.browser

/** Runs inside the page: finds MP4/M3U8 links in <video>, <source>, links and og:video tags. */
object VideoScanner {
    const val JS = """
    (function(){
      var out = {};
      function ok(p){ p = p.toLowerCase(); return p.endsWith('.mp4') || p.endsWith('.m3u8'); }
      function add(u){
        try{
          if(!u) return;
          var a = new URL(u, location.href);
          if(a.protocol !== 'http:' && a.protocol !== 'https:') return;
          if(ok(a.pathname)){ out[a.href] = 1; return; }
          a.searchParams.forEach(function(v){
            if(/^https?:\/\//i.test(v)){ try{ if(ok(new URL(v).pathname)) out[v] = 1; }catch(e){} }
          });
        }catch(e){}
      }
      document.querySelectorAll('video').forEach(function(v){
        add(v.currentSrc); add(v.src); add(v.getAttribute('data-src'));
      });
      document.querySelectorAll('source').forEach(function(s){ add(s.src); add(s.getAttribute('data-src')); });
      document.querySelectorAll('a[href]').forEach(function(a){ add(a.href); });
      document.querySelectorAll('meta[property^="og:video"], meta[name^="twitter:player:stream"]').forEach(function(m){ add(m.content); });
      return JSON.stringify(Object.keys(out));
    })()
    """
}
