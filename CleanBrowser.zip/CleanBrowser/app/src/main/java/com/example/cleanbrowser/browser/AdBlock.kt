package com.example.cleanbrowser.browser

/** Small built-in list of ad and tracker domains. A request to one of them (or a subdomain) is dropped. */
object AdBlock {
    private val domains = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "2mdn.net", "amazon-adsystem.com", "adnxs.com", "adsrvr.org",
        "taboola.com", "outbrain.com", "criteo.com", "criteo.net", "pubmatic.com", "rubiconproject.com",
        "openx.net", "advertising.com", "adform.net", "moatads.com", "scorecardresearch.com",
        "popads.net", "popcash.net", "propellerads.com", "exoclick.com", "trafficjunky.com",
        "juicyads.com", "adsterra.com", "hilltopads.net", "applovin.com", "smartadserver.com",
        "yieldmo.com", "teads.tv", "media.net", "adcolony.com", "vungle.com", "chartboost.com",
        "inmobi.com", "mgid.com", "revcontent.com", "ads.mopub.com", "unityads.unity3d.com",
        "adskeeper.com", "clickadu.com", "onclickads.net", "bidvertiser.com", "zedo.com",
    )

    fun isBlocked(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return domains.any { h == it || h.endsWith(".$it") }
    }
}
