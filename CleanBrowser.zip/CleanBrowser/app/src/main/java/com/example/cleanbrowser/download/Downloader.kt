package com.example.cleanbrowser.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.example.cleanbrowser.browser.VideoOption

object Downloader {

    /**
     * Starts the download at once. At most 3 run together; further ones wait in the queue and start
     * by themselves. A video that is already queued, paused or finished is reported as DUPLICATE.
     */
    fun enqueue(ctx: Context, option: VideoOption, pageUrl: String, userAgent: String, rawName: String): StartResult =
        DownloadEngine.enqueue(ctx, option, pageUrl, userAgent, rawName)

    fun retry(id: String) = DownloadEngine.retry(id)

    fun pauseAll() = DownloadEngine.pauseAll()

    fun resumeAll() = DownloadEngine.resumeAll()

    /** Removes the entry and deletes the file (partial or complete). */
    fun remove(ctx: Context, item: DownloadItem) = DownloadEngine.remove(ctx, item)

    /** Renames a finished file. The name always ends with .mp4. */
    fun rename(ctx: Context, item: DownloadItem, newName: String): Boolean {
        val uri = item.uri?.let { Uri.parse(it) } ?: return false
        val base = FileNames.base(newName)
        val values = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, "$base.mp4") }
        val ok = runCatching { ctx.contentResolver.update(uri, values, null, null) > 0 }.getOrDefault(false)
        if (ok) DownloadStore.change(item.id) { it.copy(name = base) }
        return ok
    }
}
