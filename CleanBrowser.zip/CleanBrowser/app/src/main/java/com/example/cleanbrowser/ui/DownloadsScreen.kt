package com.example.cleanbrowser.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.browser.ClipboardLinks
import com.example.cleanbrowser.browser.Fmt
import com.example.cleanbrowser.download.DlState
import com.example.cleanbrowser.download.DownloadItem
import com.example.cleanbrowser.download.DownloadStore
import com.example.cleanbrowser.download.Downloader
import com.example.cleanbrowser.download.FileNames

enum class DownloadsMode { Active, Completed }

private val TrackGrey = Color(0xFFBDBDBD)
private val ProgressBlue = Color(0xFF1E88E5)

/** Downloads: queued, downloading, failed. Completed: finished files. One video per card. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(mode: DownloadsMode, onPlay: (DownloadItem) -> Unit) {
    val all by DownloadStore.items.collectAsState()
    val list = all.filter { (it.state == DlState.COMPLETED) == (mode == DownloadsMode.Completed) }
    var showSettings by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (mode == DownloadsMode.Active) "Downloads" else "Completed") },
                actions = {
                    var menu by remember { mutableStateOf(false) }
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "More") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Pause all") }, onClick = { menu = false; Downloader.pauseAll() })
                        DropdownMenuItem(text = { Text("Resume all") }, onClick = { menu = false; Downloader.resumeAll() })
                        DropdownMenuItem(text = { Text("Settings") }, onClick = { menu = false; showSettings = true })
                    }
                },
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { padding ->
        if (list.isEmpty()) {
            Text(
                if (mode == DownloadsMode.Active) "No active downloads" else "No completed downloads yet",
                modifier = Modifier.padding(padding).padding(24.dp),
            )
        }
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(list, key = { it.id }) { item ->
                if (item.state == DlState.COMPLETED) CompletedCard(item) { onPlay(item) } else ActiveCard(item)
            }
        }
    }
    if (showSettings) SettingsDialog { showSettings = false }
}

/** Grey line that fills with blue as the download progresses. */
@Composable
private fun ProgressLine(fraction: Float) {
    val animated by animateFloatAsState(fraction.coerceIn(0f, 1f), label = "progress")
    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(TrackGrey)) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(animated).background(ProgressBlue))
    }
}

@Composable
private fun LinkRow(item: DownloadItem, extra: @Composable () -> Unit = {}) {
    val ctx = LocalContext.current
    Row(Modifier.padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            item.url,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(start = 4.dp),
        )
        extra()
        IconButton(onClick = {
            ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("link", item.url))
            ClipboardLinks.markHandled(ctx, item.url)
            Toast.makeText(ctx, "Link copied", Toast.LENGTH_SHORT).show()
        }) { Icon(Icons.Filled.ContentCopy, "Copy link") }
        IconButton(onClick = { Downloader.remove(ctx, item) }) { Icon(Icons.Filled.Delete, "Delete") }
    }
}

@Composable
private fun cardModifier() = Modifier.fillMaxWidth()
    .clip(RoundedCornerShape(14.dp))
    .background(MaterialTheme.colorScheme.surfaceContainerLow)
    .padding(12.dp)

/** Queued / downloading / failed: name, rate, grey-to-blue line, percentage below the line. */
@Composable
private fun ActiveCard(item: DownloadItem) {
    val fraction = if (item.total > 0) (item.downloaded.toFloat() / item.total).coerceIn(0f, 1f) else 0f
    val pct = (fraction * 100).toInt()
    val approx = if (item.isHls) "≈ " else ""

    val left = when (item.state) {
        DlState.QUEUED -> "Waiting in queue"
        DlState.PAUSED -> "Paused"
        DlState.FAILED -> item.error ?: "Download failed"
        else -> when {
            item.total > 0 -> "${Fmt.size(item.downloaded)} / $approx${Fmt.size(item.total)}"
            item.downloaded > 0 -> Fmt.size(item.downloaded)
            else -> "Starting…"
        }
    }
    val rate = if (item.state == DlState.DOWNLOADING && item.speedBps > 0) Fmt.rate(item.speedBps) else ""
    val percentText = "$pct%" + (item.note?.let { " · $it" } ?: "") + when (item.state) {
        DlState.QUEUED -> if (item.note == null) " · waiting" else ""
        DlState.PAUSED -> " · paused"
        DlState.FAILED -> " · failed"
        else -> ""
    }

    Column(cardModifier(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        // Full name, always ending in .mp4
        Text(FileNames.full(item.name), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                left, style = MaterialTheme.typography.bodySmall,
                color = if (item.state == DlState.FAILED) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f),
            )
            if (rate.isNotEmpty()) Text(rate, style = MaterialTheme.typography.labelLarge, color = ProgressBlue)
        }
        ProgressLine(fraction)
        Text(percentText, style = MaterialTheme.typography.bodySmall)        // below the line
        LinkRow(item) {
            if (item.state == DlState.FAILED) TextButton(onClick = { Downloader.retry(item.id) }) { Text("Retry") }
        }
    }
}

/** Finished file: preview, full name, size, length and whether the audio came along. Tap to play. */
@Composable
private fun CompletedCard(item: DownloadItem, onPlay: () -> Unit) {
    val uri = remember(item.uri) { item.uri?.let { Uri.parse(it) } }
    val info by rememberMediaInfo(uri)
    val ctx = LocalContext.current
    var renaming by remember { mutableStateOf(false) }
    val frame = info?.frame
    val meta = listOfNotNull(
        (info?.sizeBytes ?: item.total.takeIf { it > 0 })?.let { Fmt.size(it) },
        info?.durationSec?.let { Fmt.duration(it) },
        when (info?.hasAudio) { true -> "With audio"; false -> "No audio"; null -> null },
    ).joinToString(" · ")

    Column(cardModifier(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.clickable(onClick = onPlay), verticalAlignment = Alignment.Top) {
            Box(
                Modifier.width(112.dp).height(72.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                if (frame != null) {
                    Image(frame.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Icon(Icons.Filled.Movie, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Column(Modifier.weight(1f).padding(start = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(FileNames.full(item.name), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                if (meta.isNotEmpty()) {
                    Text(
                        meta, style = MaterialTheme.typography.bodySmall,
                        color = if (info?.hasAudio == false) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        LinkRow(item) {
            IconButton(onClick = { renaming = true }) { Icon(Icons.Filled.Edit, "Rename") }
        }
    }

    if (renaming) {
        RenameDialog(item.name, onDismiss = { renaming = false }) { newName ->
            val ok = Downloader.rename(ctx, item, newName)
            Toast.makeText(ctx, if (ok) "Renamed" else "Couldn't rename", Toast.LENGTH_SHORT).show()
            renaming = false
        }
    }
}

@Composable
private fun RenameDialog(initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rename") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                suffix = { Text(".mp4") },
                minLines = 1,
                maxLines = 5,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text("Rename") } },
    )
}
