package com.example.cleanbrowser.download

import android.content.Context

/** Remembers the resolution the user picked last, so the next download pre-selects it. */
object ResolutionPrefs {
    private const val FILE = "prefs"
    private const val KEY = "last_height"

    fun get(ctx: Context): Int =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt(KEY, 0)

    fun set(ctx: Context, height: Int) {
        if (height > 0) ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt(KEY, height).apply()
    }
}
