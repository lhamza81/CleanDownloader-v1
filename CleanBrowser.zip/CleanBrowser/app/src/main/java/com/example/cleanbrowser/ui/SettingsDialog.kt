package com.example.cleanbrowser.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.download.AppSettings

@Composable
fun SettingsDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val s by AppSettings.state.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                SwitchRow("Download with Wi-Fi only", "Waiting downloads start when you are on Wi-Fi", s.wifiOnly) { v ->
                    AppSettings.update(ctx) { it.copy(wifiOnly = v) }
                }
                SwitchRow("Block ads", "Drops known ad and tracker domains in the browser", s.blockAds) { v ->
                    AppSettings.update(ctx) { it.copy(blockAds = v) }
                }
                SwitchRow("Offer copied links", "Asks to open a link you just copied", s.clipboard) { v ->
                    AppSettings.update(ctx) { it.copy(clipboard = v) }
                }
                ChoiceRow("Simultaneous downloads", "Extra downloads wait in the queue", listOf(1, 2, 3), s.maxParallel) { v ->
                    AppSettings.update(ctx) { it.copy(maxParallel = v) }
                }
                ChoiceRow("Connections per file", "More connections download big files faster on most sites", listOf(1, 2, 3, 4), s.connections) { v ->
                    AppSettings.update(ctx) { it.copy(connections = v) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

@Composable
private fun SwitchRow(title: String, hint: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ChoiceRow(title: String, hint: String, options: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.bodyMedium)
        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 2.dp)) {
            options.forEach { n ->
                FilterChip(selected = selected == n, onClick = { onPick(n) }, label = { Text("$n") })
            }
        }
    }
}
