package com.example.cleanbrowser

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.example.cleanbrowser.browser.ClipboardLinks
import com.example.cleanbrowser.browser.TabManager
import com.example.cleanbrowser.browser.TabStore
import com.example.cleanbrowser.download.AppSettings

class BrowserViewModel(app: Application) : AndroidViewModel(app) {
    val tabManager = TabManager(app).also { m ->
        val saved = TabStore.load(app)
        if (saved != null) m.restore(saved) else m.newTab()
    }

    /** A link found on the clipboard, offered once ("Link you copied"). */
    var clipboardLink by mutableStateOf<String?>(null)
        private set

    fun checkClipboard(ctx: Context) {
        if (clipboardLink != null || !AppSettings.state.value.clipboard) return
        ClipboardLinks.read(ctx)?.let { clipboardLink = it }
    }

    fun dismissClipboard() { clipboardLink = null }

    override fun onCleared() {
        tabManager.destroyAll()
    }
}
