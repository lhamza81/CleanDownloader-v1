package com.example.cleanbrowser.download

import java.net.URI

object Hls {
    class Variant(
        val url: String, val width: Int, val height: Int,
        val bandwidth: Long, val codecs: String?, val audioGroup: String?,
    )

    class AudioRendition(val url: String, val isDefault: Boolean)

    class Master(val variants: List<Variant>, val audio: Map<String, List<AudioRendition>>) {
        /** Separate audio playlist for this variant, if the stream keeps audio apart from video. */
        fun audioFor(v: Variant): String? {
            val list = v.audioGroup?.let { audio[it] } ?: return null
            return (list.firstOrNull { it.isDefault } ?: list.firstOrNull())?.url
        }
    }

    class Media(
        val initUrl: String?, val segments: List<String>, val seconds: Double?,
        val live: Boolean, val encrypted: Boolean, val byteRange: Boolean,
    ) {
        /** Live, encrypted and byte-range streams can't be saved. */
        val usable: Boolean get() = !live && !encrypted && !byteRange && segments.isNotEmpty()
    }

    fun isMaster(text: String) = text.contains("#EXT-X-STREAM-INF")

    fun resolve(base: String, ref: String): String = URI(base).resolve(ref).toString()

    private fun attrs(s: String): Map<String, String> =
        Regex("([A-Z0-9-]+)=(\"[^\"]*\"|[^,]*)").findAll(s)
            .associate { it.groupValues[1] to it.groupValues[2].trim('"') }

    fun parseMaster(text: String, base: String): Master {
        val lines = text.lines().map { it.trim() }
        val variants = mutableListOf<Variant>()
        val audio = HashMap<String, MutableList<AudioRendition>>()
        for (i in lines.indices) {
            val l = lines[i]
            if (l.startsWith("#EXT-X-STREAM-INF:")) {
                val a = attrs(l.substringAfter(':'))
                val uri = lines.drop(i + 1).firstOrNull { it.isNotEmpty() && !it.startsWith("#") } ?: continue
                val res = a["RESOLUTION"]?.split('x')
                variants.add(Variant(
                    url = resolve(base, uri),
                    width = res?.getOrNull(0)?.toIntOrNull() ?: 0,
                    height = res?.getOrNull(1)?.toIntOrNull() ?: 0,
                    bandwidth = (a["AVERAGE-BANDWIDTH"] ?: a["BANDWIDTH"])?.toLongOrNull() ?: 0L,
                    codecs = a["CODECS"],
                    audioGroup = a["AUDIO"],
                ))
            } else if (l.startsWith("#EXT-X-MEDIA:")) {
                val a = attrs(l.substringAfter(':'))
                val group = a["GROUP-ID"]
                val uri = a["URI"]
                if (a["TYPE"] == "AUDIO" && group != null && uri != null) {
                    audio.getOrPut(group) { mutableListOf() }.add(AudioRendition(resolve(base, uri), a["DEFAULT"] == "YES"))
                }
            }
        }
        return Master(variants, audio)
    }

    fun parseMedia(text: String, base: String): Media {
        val lines = text.lines().map { it.trim() }
        var initUrl: String? = null
        var total = 0.0
        var encrypted = false
        var byteRange = false
        for (l in lines) {
            when {
                l.startsWith("#EXT-X-KEY:") && !l.contains("METHOD=NONE") -> encrypted = true
                l.startsWith("#EXT-X-MAP:") -> {
                    val a = attrs(l.substringAfter(':'))
                    a["URI"]?.let { initUrl = resolve(base, it) }
                    if (a.containsKey("BYTERANGE")) byteRange = true
                }
                l.startsWith("#EXT-X-BYTERANGE") -> byteRange = true
                l.startsWith("#EXTINF:") -> total += l.substringAfter(':').substringBefore(',').toDoubleOrNull() ?: 0.0
            }
        }
        val segments = lines.filter { it.isNotEmpty() && !it.startsWith("#") }.map { resolve(base, it) }
        val live = lines.none { it == "#EXT-X-ENDLIST" }
        return Media(initUrl, segments, if (live || total <= 0) null else total, live, encrypted, byteRange)
    }
}
